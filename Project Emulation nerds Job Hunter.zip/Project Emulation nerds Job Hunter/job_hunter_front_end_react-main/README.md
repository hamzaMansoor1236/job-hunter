# Getting Started with Create React App

This project was bootstrapped with [Create React App](https://github.com/facebook/create-react-app).

## Available Scripts to run project

1 Move into project directory
cd job_hunter_front_end_react


2 In the project directory, you can run:
### `npm start`

Runs the app in the development mode.\
3 Open [http://localhost:3000](http://localhost:3000) to view it in your browser.
